# Build Your First 3D Game in Unity | Unity Beginner Tutorial

Watch the course here: https://www.youtube.com/playlist?list=PLrnPJCHvNZuB5ATsJZLKX3AW4V9XaIV9b

![thumbnail part 1](https://user-images.githubusercontent.com/52977034/122668077-ba9c7180-d1b6-11eb-94a8-d6ade2f5af31.png)
